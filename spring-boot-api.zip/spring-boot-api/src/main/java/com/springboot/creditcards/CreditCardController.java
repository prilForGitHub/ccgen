package com.springboot.creditcards;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CreditCardController {
	private static final String AMERICAN_EXPRESS_37 = "37";
	private static final String MASTER_5 = "5";
	private static final String VISA_4 = "4";
	private static final int CREDIT_CARD_NUMBER_LENGTH = 16;
	private static final String DISCOVER_6 = "6";
	@Autowired
	private CreditCardNumberGenerator creditCardNumberGenerator;
	@Autowired
	private CreditCardNumberValidator creditCardNumberValidator;

	public static final String CC_URI = "/ccengine/{type}/{count}";

	@RequestMapping(CC_URI)
	public CardResponse getAllTopics(@PathVariable("type") final String type, @PathVariable("count") final int count) {
		List<String> list = new ArrayList<>();
		if (null != type && type.equalsIgnoreCase(CardType.Visa.toString())) {
			for (int j = 0; j <= count - 1; j++) {
				String cardNumber = creditCardNumberGenerator.generate(VISA_4, CREDIT_CARD_NUMBER_LENGTH);

				validateCCNumber(list, cardNumber);
			}
		} else if (null != type && type.equalsIgnoreCase(CardType.Master.toString())) {
			for (int j = 0; j <= count - 1; j++) {
				String cardNumber = creditCardNumberGenerator.generate(MASTER_5, CREDIT_CARD_NUMBER_LENGTH);

				validateCCNumber(list, cardNumber);
			}
		} else if (null != type && type.equalsIgnoreCase(CardType.AmericanExpress.toString())) {
			for (int j = 0; j <= count - 1; j++) {
				String cardNumber = creditCardNumberGenerator.generate(AMERICAN_EXPRESS_37, CREDIT_CARD_NUMBER_LENGTH);

				validateCCNumber(list, cardNumber);
			}
		} else if (null != type && type.equalsIgnoreCase(CardType.Discover.toString())) {
			for (int j = 0; j <= count - 1; j++) {
				String cardNumber = creditCardNumberGenerator.generate(DISCOVER_6, CREDIT_CARD_NUMBER_LENGTH);

				validateCCNumber(list, cardNumber);
			}
		}else {
			list.add("Please provide valid card type");
		}

		CardResponse cardResponse = new CardResponse();
		cardResponse.setNumbers(list);
		cardResponse.setExpiry(new Date());
		return cardResponse;
	}

	private void validateCCNumber(List<String> list, String cardNumber) {
		int[] num = new int[cardNumber.length()];

		for (int i = 0; i < cardNumber.length(); i++) {
			num[i] = cardNumber.charAt(i) - '0';
		}

		if (creditCardNumberValidator.check(num)) {
			list.add(cardNumber);
		}
	}
}
