package com.springboot.creditcards;

import java.util.Date;
import java.util.List;

public class CardResponse {

	private List<String> numbers;
	private Date expiry;
	public List<String> getNumbers() {
		return numbers;
	}
	public void setNumbers(List<String> numbers) {
		this.numbers = numbers;
	}
	public Date getExpiry() {
		return expiry;
	}
	public void setExpiry(Date expiry) {
		this.expiry = expiry;
	}
	
	
}
