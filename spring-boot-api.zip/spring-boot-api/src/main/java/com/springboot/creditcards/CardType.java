package com.springboot.creditcards;

public enum CardType {
	Visa, Master, AmericanExpress, Discover
}
